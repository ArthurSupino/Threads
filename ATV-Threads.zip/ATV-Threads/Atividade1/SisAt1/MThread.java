public class MThread extends Thread {
    private Runnable run;
    public MThread(Runnable run)
    {
        this.run = run;
    }
    public void run()
    {
        this.run.run();
    }
    
}