package Atividade6.SisAtv6;

public class Produtor implements Runnable {
    private final Fila fila;
    private final int id; 
    private static int totalProduzidos = 0; 
    private static final int LIMITE = 100;

    public Produtor(Fila fila, int id) {
        this.fila = fila;
        this.id = id;
    }

    @Override
    public void run() {
        int valor = 0;
        while (true) {
            synchronized (Produtor.class) 
            { 
                if (totalProduzidos >= LIMITE) {
                    break; 
                }
            }
            try {
                fila.produzir(valor);
                System.out.println("Produtor " + id + " produziu: " + valor);
                valor++;
                
                synchronized (Produtor.class) {
                    totalProduzidos++; 
                }

                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break; 
            }
        }
        System.out.println("Produtor " + id + " terminou a produção.");
    }
}

