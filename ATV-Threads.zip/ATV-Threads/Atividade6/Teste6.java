package Atividade6;

import Atividade6.SisAtv6.*;


public class Teste6{
    public static void main(String[] args) {
        Fila fila = new Fila(10); 
        for (int i = 0; i < 5; i++) {
            new Thread(new Produtor(fila, i + 1)).start(); 
        }

        for (int i = 0; i < 3; i++) {
            new Thread(new Consumidor(fila)).start();
        }
    }
}

