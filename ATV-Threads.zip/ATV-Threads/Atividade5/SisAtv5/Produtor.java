package Atividade5.SisAtv5;

public class Produtor implements Runnable 
{

    private Fila fila;

    public Produtor(Fila fila) 
    {
        this.fila = fila;
    }

    public void run() 
    {
        int valor = 0;
        while (valor < 100) 
        {
            try 
            {
                fila.produzir(valor);
                valor++;
                Thread.sleep(100); 
            } catch (InterruptedException e) 
            {
                Thread.currentThread().interrupt();
            }
          
        }
    }
}