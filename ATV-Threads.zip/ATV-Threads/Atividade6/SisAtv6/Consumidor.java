package Atividade6.SisAtv6;

public class Consumidor implements Runnable {
    private final Fila fila;

    public Consumidor(Fila fila) {
        this.fila = fila;
    }

    @Override
    public void run() {
        while (true) {
            try {
                fila.consumir();
                Thread.sleep(150); // Pausa para simular tempo de consumo
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break; // Sai do método run() se a thread for interrompida
            }
        }
    }
}
