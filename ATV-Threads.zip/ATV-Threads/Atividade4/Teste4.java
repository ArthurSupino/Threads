package Atividade4;

import Atividade4.SisAtv4.*;

public class Teste4 
{
    
    public static void main(String[] args) 
    {
        Common runner = new Common();
        MThread t1 = new MThread(runner);
        MThread t2 = new MThread(runner);
        MThread t3 = new MThread(runner);
        MThread t4 = new MThread(runner);
        MThread t5 = new MThread(runner);
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();

        try {
            t1.join();
            t2.join();
            t3.join();
            t4.join();
            t5.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Valor final do contador: " + runner.getIncrementador());
    }
}
