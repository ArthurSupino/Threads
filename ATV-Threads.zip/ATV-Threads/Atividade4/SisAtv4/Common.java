package Atividade4.SisAtv4;

public class Common 
{
    private int incrementador = 0;

    public synchronized void incrementer() 
    {
        incrementador++;
    }

    public int getIncrementador() 
    {
        return incrementador;
    }
}