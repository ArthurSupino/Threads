import java.util.Random;

public class Mrunnable implements Runnable
{

    public void run() 
    {
        this.treino();        
    }

    public void treino()
    {   
        //teste de como se usa os Threads
        Random rand;
        rand = new Random();
        for(int i = 0 ; i < 10 ; i++)
        {
            if(rand.nextInt(50) == 20)
            {
                System.out.println("Minha primeira Thread");
            }

        }
    }
    
    
}