public class Teste 
{
    public static void main(String[] args) {
        Mrunnable run = new Mrunnable();
        MThread thread = new MThread(run);
        thread.start();
    }   
}
