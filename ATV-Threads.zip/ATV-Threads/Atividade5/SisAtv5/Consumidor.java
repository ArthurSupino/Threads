package Atividade5.SisAtv5;

public class Consumidor implements Runnable {
    private Fila fila;

    public Consumidor(Fila fila) {
        this.fila = fila;
    }

    @Override
    public void run() {

        while (true) {
            try {
                fila.consumir();
                Thread.sleep(150); 
            } catch (InterruptedException e) 
            {
                Thread.currentThread().interrupt();
            }
         
        }
    }
}