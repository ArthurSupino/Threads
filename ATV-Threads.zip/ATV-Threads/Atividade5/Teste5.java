package Atividade5;
import Atividade5.SisAtv5.*;

public class Teste5 
{
    public static void main(String[] args) 
    {
        Fila fila = new Fila(10); 
        Thread produtor = new Thread(new Produtor(fila));
        Thread consumidor = new Thread(new Consumidor(fila));

        produtor.start();
        consumidor.start();

        if(fila.encerra())
        {
        produtor.interrupt();
        consumidor.interrupt();
        }
    }
}
