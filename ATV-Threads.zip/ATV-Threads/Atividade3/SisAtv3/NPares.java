package Atividade3.SisAtv3;


public class NPares implements Runnable
{
    private final Object sincronizador;
    //Criando um objeto para determinar a sincronia dos Threads 
    public NPares(Object a)
    {
            this.sincronizador = a;
    }
        
        public void run() 
        {
            for (int i = 0; i <= 10; i += 2) {  
                System.out.println("Par: " + i);
                synchronized(sincronizador)
                {
                    sincronizador.notify(); 
                    try {
                        sincronizador.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
            }
                
            } 
        
        }
}
