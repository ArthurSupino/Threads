package Atividade5.SisAtv5;
import java.util.LinkedList;
import java.util.Queue;

public class Fila {
    private Queue<Integer> fila;
    private int capacidade;

  
    public Fila(int capacidade) 
    {
        this.fila = new LinkedList<>();
        this.capacidade = capacidade;
    }

    public synchronized void produzir(int valor) throws InterruptedException 
    {
        while (fila.size() == capacidade) 
        {
            wait(); 
        }
        fila.add(valor);
        System.out.println("Produzido: " + valor);
        notify(); 
    }

    public synchronized int consumir() throws InterruptedException 
    {
        while (fila.isEmpty()) 
        {
            wait(); 
        }
        int valor = fila.poll();
        if(valor < 100)
        {
        System.out.println("Consumido: " + valor);
        notify(); 
        if(valor == 99)
        {
            encerra();
        } 
        }
        return valor;
    }
    public int getCapacidade() 
    {
        return capacidade;
    }
    public boolean encerra()
    {
        System.out.println("finalizando");
        return true;
    }
}