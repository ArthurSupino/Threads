package Atividade6.SisAtv6;

import java.util.LinkedList;
import java.util.Queue;

public class Fila {
    private final Queue<Integer> fila;
    private final int capacidade;

    public Fila(int capacidade) {
        this.fila = new LinkedList<>();
        this.capacidade = capacidade;
    }

    public synchronized void produzir(int item) throws InterruptedException {
        while (fila.size() == capacidade) {
            wait(); 
        }
        fila.add(item);
        System.out.println("Produzido: " + item);
        notifyAll(); 
    }

    public synchronized int consumir() throws InterruptedException {
        while (fila.isEmpty()) {
            wait(); 
        }
        int item = fila.poll();
        System.out.println("Consumido: " + item);
        notifyAll(); 
        return item;
    }
}


