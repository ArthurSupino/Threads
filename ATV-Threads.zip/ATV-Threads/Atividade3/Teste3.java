package Atividade3;


import Atividade3.SisAtv3.*;


public class Teste3 
{
   public static void main(String[] args) {
    //usado um parametro da classe object ja que ele é comum a todas as classes , vai ser usado como monitoramento dos Threads
        Object parametro = new Object();
        MThread threadPares = new MThread(new NPares(parametro));
        MThread threadImpares = new MThread(new NImpares(parametro));

        threadPares.start();
        threadImpares.start();
    } 
}
