package Atividade4.SisAtv4;

public class MThread extends Thread
{
    private final Common contador;
    public MThread(Common run)
    {
        this.contador = run;
    }
    public void run() {
        for (int i = 0; i < 100000; i++) {
            contador.incrementer();
        }
        System.out.println("Thread " + Thread.currentThread().getName() + " terminou de incrementar.");
    }
}
    

