package Atividade2;
import Atividade2.SisAt2.*;

public class Teste2 
{
    public static void main(String[] args) {
        MThread threadPares = new MThread(new NPares());
        MThread threadImpares = new MThread(new NImpaers());

        threadPares.start();
        threadImpares.start();
    }
}
