package Atividade3.SisAtv3;


public class NImpares implements Runnable
{
    private final Object sincronizador;

    public NImpares(Object a)
    {
            this.sincronizador = a;
    }
        
        public void run() 
        {
            for (int i = 1; i <= 10; i += 2) {  
                System.out.println("Impar: " + i);
                synchronized(sincronizador)
                {
                    sincronizador.notify(); 
                    try {
                        sincronizador.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
            }
                
            } 
        
        }
    }
